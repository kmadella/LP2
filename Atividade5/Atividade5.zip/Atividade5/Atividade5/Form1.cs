﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtAliINSS_Validated(object sender, EventArgs e)
        {
        
        }

        private void btnDesconto_Click(object sender, EventArgs e)
        {
            {
                double salarioBruto, descontoINSS;
                double teto = 308.17;

                double.TryParse(mskbxSalarioBruto.Text, out salarioBruto);
                double.TryParse(txtDescINSS.Text, out descontoINSS);



                if (salarioBruto <= 800.47)
                {
                    txtAliINSS.Text = "7,65%";
                    descontoINSS = 0.0765 * salarioBruto;
                }
                else if (salarioBruto <= 1050.01)
                {
                    txtAliINSS.Text = "8,65%";
                    descontoINSS = (0.0865 * salarioBruto);
                }
                else if (salarioBruto <= 1400.78)
                {
                    txtAliINSS.Text = "11%";
                    descontoINSS = 1.1 * salarioBruto;
                }
                else if (salarioBruto < 2801.56)
                {
                    txtAliINSS.Text = "Teto";
                    descontoINSS = teto;
                }
               
                txtDescINSS.Text = descontoINSS.ToString("N2");

                MessageBox.Show("Salário Bruto: " + salarioBruto.ToString("N2"));
                MessageBox.Show("Desconto INSS: " + descontoINSS.ToString("N2"));


            }           
            
        }

        private void mskbxSalarioBruto_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void mskbxSalarioBruto_Validated(object sender, EventArgs e)
        {
         
        }
    }
}
