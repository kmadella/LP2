﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace PDESPESA0030482311008
{
    public partial class frmPrincipal : Form
    {
        public static SqlConnection conexao;

        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void FormPrincipal_Load(object sender, EventArgs e)
        {
            try
            {
                // aqui a conexão vai depende da sua máquina da escola ou particular
                conexao = new SqlConnection("Data Source=DESKTOP-7MQ2DAK;Initial Catalog=LP2;Integrated Security=True");
                conexao.Open();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Erro de banco de dados =/" + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Outros Erros =/" + ex.Message);
            }
        }

        private void cadastroDespesaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmDespesa1>().Count() > 0)
            {
                Application.OpenForms["frmDespesa1"].BringToFront();
            }
            else
            {
                frmDespesa1 objDesp = new frmDespesa1();
                objDesp.MdiParent = this;
                objDesp.WindowState = FormWindowState.Maximized;
                objDesp.Show();
            }
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmsobre>().Count() > 0)
            {
                Application.OpenForms["frmsobre"].BringToFront();
            }
            else
            {
                frmsobre objDesp = new frmsobre();
                objDesp.MdiParent = this;
                objDesp.WindowState = FormWindowState.Maximized;
                objDesp.Show();
            }

        }
    }
}
