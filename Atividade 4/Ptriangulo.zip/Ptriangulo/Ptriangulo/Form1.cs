﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
       

        public Form1()
        {
            InitializeComponent();
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtValA_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtValA, "");
            double valorA;

            if (!double.TryParse(txtValA.Text, out valorA))
            {
                errorProvider1.SetError(txtValA, "Valor de A inválido");
            }
        }

        private void TxtValB_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtValB, "");
            double valorB;

            if (!double.TryParse(txtValB.Text, out valorB))
            {
                errorProvider1.SetError(txtValB, "Valor de B inválido");
            }
        }

        private void TxtValC_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtValC, "");
            double valorC;

            if (!double.TryParse(txtValC.Text, out valorC))
            {
                errorProvider1.SetError(txtValC, "Valor de C inválido");
            }
        }

        private void BtnVerificar_Click(object sender, EventArgs e)
        {
            double valorA, valorB, valorC;

            //testar se os valores sao validos
            if (!double.TryParse(txtValA.Text, out valorA) ||
                !double.TryParse(txtValB.Text, out valorB) ||
                !double.TryParse(txtValC.Text, out valorC))
            {
                MessageBox.Show("valores devem ser numéricos");
            }
            else
            {
                //condicao necessaria para ser triangulo
                if (valorA < (valorB + valorC) && valorA >
                    Math.Abs(valorB - valorC) && valorB < (valorA + valorC)
                    && valorC < (valorA + valorB) &&
                    valorC > Math.Abs(valorA - valorB))
                {
                    if (valorA == valorB && valorB == valorC)
                        MessageBox.Show("Triangulo Equilatero");
                    else if (valorA == valorB || valorA == valorC || valorB == valorC)
                        MessageBox.Show("Triangulo Isosceles");
                    else
                        MessageBox.Show("Triangulo Escaleno");
                }
                else
                    MessageBox.Show($"Os valores {valorA}, {valorB}, {valorC}, nao formam um triangulo");
            }
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtValA.Clear();
            txtValB.Clear();
            txtValC.Clear();
            errorProvider1.SetError(txtValA, "");
            errorProvider2.SetError(txtValB, "");
            errorProvider3.SetError(txtValC, "");
        }
    }
}


















        