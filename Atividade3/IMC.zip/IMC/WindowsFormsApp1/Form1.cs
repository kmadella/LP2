﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;

        private void txtPeso_TextChanged(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtPeso.Text, out peso))
            {
                MessageBox.Show("Peso inválido");
                txtPeso.Focus();
            }


        private void txtAltura_TextChanged(object sender, EventArgs e)
        {
            if(!double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Altura inválida");
                txtAltura.Focus();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            imc = peso / (altura * altura);
            txtIMC.Text = imc.ToString();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPeso.Text = "";
            txtAltura.Text = "";
            txtIMC.Text = "";

            txtPeso.Focus();
            imc = 0;
            peso = 0;
            altura = 0;
        }

        public Form1()
        {
            InitializeComponent();
        }

        


        }
    }
}
